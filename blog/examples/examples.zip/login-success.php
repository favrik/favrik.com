<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
 "http://www.w3.org/TR/html4/loose.dtd">
<html lang="es">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link rel="shortcut icon" href="/favicon.ico">
  <link rel="stylesheet" href="css/blueprint/screen.css" type="text/css" media="screen, projection">
    <link rel="stylesheet" href="css/blueprint/print.css" type="text/css" media="print">
  <link rel="stylesheet" href="css/screen.css" type="text/css" media="screen">
  <title>PROFEPA. La Ley al Servicio de la Naturaleza.</title>

  <script type="text/javascript" src="js/jquery.pack.js"></script>
  <script type="text/javascript" src="js/jquery.form.js"></script>
    <script type="text/javascript" charset="utf8" src="js/login.js"></script>
    <!--[if lt IE 7.]>
    <script defer type="text/javascript" src="/inspeccion/js/pngfix.js"></script>
    <![endif]-->
</head>
<body id="login">
<div class="container span-12">
    <div id="content" class="column span-12 first last">
        <div class="column span-3 first">&nbsp;</div>

    <div class="column span-6 last">
        <h1>Login exitoso</h1>
        <p>Felicidades ya estás autentificado O.o.</p>
        
    <div class="column span-3 last">&nbsp;</div>
    </div>
</div>
</body>
</html>